public class Q01 {
    public static void main(String[] args) {
        final int[] lista = {1, 2, 3, 4};
        int soma = 0;

        for (int j : lista) {
            soma += j;
        }
        System.out.println(soma);
    }
}
